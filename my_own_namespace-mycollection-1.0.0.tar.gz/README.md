
Documentation for the collection.

Ansible collection  **my_own_namespace.mycollection** version 1.0.0

Collection makes a text file on host in any arbitrary path and filename and fills in with text defined in playbook.